
    @php
         use App\Models\Entreprise;

        // dd($contrats);
    @endphp
    <div class="col-xs-12">
        <div class="box ">
            
            <div class="box-header">
            <h3 class="box-title">Bases de données des contrats</h3><br><br>
                <a href="contrat" style="color:blue"><u>Rétablir<i class="fa fa-refresh" aria-hidden="true"></i></u></a> &emsp;&emsp;&emsp;&emsp; <label>Filtrer par:</label>
            
                <div class="row">
                    <div class="col-md-2 form-group">
                        <select class="form-control select2"  wire:model.debounce.250ms="id_entreprise" id="id_entreprise">
                            <option value="">Entreprises</option>
                            @php
                                $get =  $entreprisecontroller->GetAll();
                            @endphp
                            
                            @foreach($get as $entreprise)
                                <option value={{$entreprise->id}}>{{$entreprise->nom_entreprise}}</option>
                                
                            @endforeach
                            
                        </select>   
                    </div>    

                    <div class="col-md-2 form-group">
                
                        <select class="form-control select2" wire:model.debounce.250ms="reconduction" id="reconduction">
                        
                            <option value="">Renouvellement</option>
                            <option value="0">Non</option>
                            <option value="1">Tacite</option>
                            <option value="2">Accord parties</option>
                        </select>
                                                
                    </div>

                    <div class="col-md-2 form-group">
                
                        <select class="form-control select2" id="etat_contrat"  wire:model.debounce.250ms="etat_contrat">
                            <option value="">Etat</option>
                            <option value="0">En cours</option>
                            <option value="1">Terminé</option>
                        </select>
                                                
                    </div>

                    <div class="col-md-4 form-group">
                        <select class="form-control input-lg select2" id="service" wire:model.debounce.250ms="service">
                            <!--liste des services a choisir -->
                            <option value="service">Service</option>
                            @php
                                $get = $servicecontroller->GetAll();
                                $categorie = $categoriecontroller->DisplayAll();
                            @endphp
                            @foreach( $categorie as $categorie)
                                
                                <optgroup label="{{$categorie->libele_categorie}}">{{$categorie->libele_categorie}}</optgroup>
                                @php
                                    $get = $servicecontroller->GetByCategorieNoSusp($categorie->id);
                                    
                                @endphp
                                @foreach($get as $service)
                                    <option value={{$service->id}}>{{$service->libele_service}}</option>
                                    
                                @endforeach
                            @endforeach
                                
                        </select>
                    </div>

                
                    
                </div>

        
                <div class="box-tools">
                    <a href="form_add_contrat" class="mr-4 d-block"><button class="btn btn-primary"> <b><i class="fa fa-plus"></i> CONTRAT</b></button></a><br>
                    <div class="input-group input-group-sm" style="width: 300px;">
                        <input type="text" id="search" wire:model.debounce.250ms="search" class="form-control pull-right" placeholder="Rechercher">

                        <div class="input-group-btn">
                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </div>
                
        
            

            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
                <table class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                    <th>Titre de contrat</th>
                    <th>Entreprise</th>
                    <th>Début du contrat</th>
                    <th>Fin du contrat</th>
                    <th>Montant</th>	
                    <th>Services</th><!--LA LISTE DES SERVICES -->
                    <th>Fichier du contrat</th>
                    <th>Bond de commande</th>
                    @if(auth()->user()->id_role == 3)
                    @else
                    <th>Modifier</th>
                    @endif
                
                </tr>
                </thead>
                <tbody>
                    @forelse($contrats as $contrat)
                        <tr>
                            <td>{{$contrat->titre_contrat}}</td>
                            <td>
                            {{$contrat->nom_entreprise}}
                                
                            </td>
                            <td>@php echo date('d/m/Y',strtotime($contrat->debut_contrat)) @endphp</td>
                            <td>@php echo date('d/m/Y',strtotime($contrat->fin_contrat)) @endphp</td>
                            <td>
                                @php
                                echo  number_format($contrat->montant, 2, ".", " ")." XOF";
                                @endphp
                            
                            </td>  
                        
                            <td>
                                @php
                                
                                    //On va écrire un code pour detecter tous les services offerts
                                    $se = DB::table('prestation_services')
                                    ->join('prestations', 'prestation_services.prestation_id', '=', 'prestations.id')
                                    ->join('services', 'prestation_services.service_id', '=', 'services.id') 
                                    ->join('contrats', 'prestations.id_contrat', '=', 'contrats.id') 
                                    ->where('prestations.id_contrat', $contrat->id)
                                    ->get(['services.libele_service', 'prestation_services.*']);
                                    
                                @endphp
                                <ul>
                                @foreach($se as $se_get)
                                    <li>{{$se_get->libele_service}}</li>
                                @endforeach
                                </ul>
                            </td>
                            <td>
                                <form action="download" method="post" enctype="multipart/form-data" target="blank">
                                @csrf
                                
                                    <input type="text" value={{$contrat->id}} style="display:none;" name="id_contrat">
                                <input type="text" class="form-control" name="file" value="{{$contrat->path}}" style="display:none;">
                                <button type="submit" class="btn btn-warning"><i class="fa fa-download"></i></button>
                                </form>
                                
                            </td>
                        
                            <td>
                                <form action="view_bon_commande" method="post" enctype="multipart/form-data" target="blank">
                                    @csrf
                                    
                                    <input type="text" value={{$contrat->id}} style="display:none;" name="id_contrat">
                                    <input type="text" class="form-control" name="file_bon" value="{{$contrat->bon_commande}}" style="display:none;">
                                    <button type="submit" class="btn btn-warning"><i class="fa fa-download"></i></button>
                                </form>
                            
                            </td>

                            @if(auth()->user()->id_role == 3)
                            @else
                    
                                <td>
                                <!--MODIFICATION AVEC POPUP-->
                            
                                <!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="">
                                <i class="fa fa-edit"></i>
                                </button>-->
                                <button type="button" class="btn btn-primary" wire:click="EditContrat('{{$contrat->id}}')">
                                <i class="fa fa-edit"></i>
                                </button>
                                    

                                </td>
                            @endif  
                        </tr>
                    @empty

                    <tr colspan="9">
                            <div class="alert alert-info alert-dismissible">
                                
                                <h4><i class="icon fa fa-ban"></i> Oups!</h4>
                                Aucune donnée trouvée
                            </div>
                        </tr>
                    @endforelse
                </tbody>
                
                </table>
            </div>
            <!-- /.box-body -->

            <div clas="box-footer clearfix">
                <ul class="pagination pagination-sm no-margin pull-right">
                    {{$contrats->links()}}
                </ul>
                    
            </div>
        </div>
        <!-- /.box -->
    </div>
